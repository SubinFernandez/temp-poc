export const API_ENDPOINTS = {
  INVOICE: 'http://18.130.231.217/invoice/'
}

export const ROUTES = {
  DASHBOARD: '/dashboard',
  INVOICE: '/invoice/'
}